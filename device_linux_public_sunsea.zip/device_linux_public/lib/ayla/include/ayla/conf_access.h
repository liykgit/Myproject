/*
 * Copyright 2016-2017 Ayla Networks, Inc.  All rights reserved.
 *
 * Use of the accompanying software is permitted only in accordance
 * with and subject to the terms of the Software License Agreement
 * with Ayla Networks, Inc., a copy of which can be obtained from
 * Ayla Networks, Inc.
 */
#ifndef __AYLA_CONF_ACCESS_H__
#define __AYLA_CONF_ACCESS_H__

/*
 * Header to support legacy applications.  Please use the below header for
 * new development.
 */
#include <app/conf_access.h>

#endif /* __AYLA_CONF_ACCESS_H__ */
