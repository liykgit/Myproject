#!/bin/sh
#
# Copyright (C) 2014 www.aylanetworks.com
#
#

export REQUEST_URI="/push_button_reg.json"
export CONTENT_LENGTH="0"
export REQUEST_METHOD="POST"
export HTTP_ACCEPT="application/json"
/sbin/acgi -l &

