Release Notes For Gateway Setup Package

Package Part Number: AY004TGW0

This package sets up the gateway to use the Ayla cloud service.
It may perform some manufacturing tests as well.

After unzipping the package, rename gw_setup-* to gw_setup.

For install and usage instructions, please see:

	Ayla Linux Agent Setup, part AY006TGW0.

Change log:

Release: 0.1

*  Initial release
*  Requires image build verison TBD.

--- End
